import { AttackSimulator } from '../../src/simulation/AttackSimulator';

async function run() {
  console.log("Starting synthetic telemetry injection...");
  
  // Generate a batch of events using our existing simulator
  const events = AttackSimulator.generate('LATERAL_MOVEMENT');
  
  // POST them to our new local ingestion API
  try {
    const res = await fetch('http://localhost:3001/api/ingest', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(events)
    });
    
    if (res.ok) {
      console.log(`Successfully ingested ${events.length} synthetic events!`);
    } else {
      console.error("Failed to ingest events:", res.statusText);
    }
  } catch (error) {
    console.error("Error communicating with backend:", error);
  }
}

run();
