import express from 'express';
import cors from 'cors';
import { db, initDb } from './db/setup';
import { SecurityAnalyzer } from '../../src/engine/Analyzer';

const app = express();
app.use(cors());
app.use(express.json());

// Initialize SQLite schema
initDb();

// 1. INGESTION LAYER
// Endpoint logs, cloud logs, etc. will hit this API
app.post('/api/ingest', (req, res) => {
  const events = Array.isArray(req.body) ? req.body : [req.body];
  
  const insert = db.prepare(`
    INSERT INTO events (id, timestamp, action, user, ip, details)
    VALUES (@id, @timestamp, @action, @user, @ip, @details)
  `);

  const insertMany = db.transaction((events) => {
    for (const event of events) {
      // In a real system, normalization would happen here before saving
      insert.run({
        id: event.id || `evt-${Math.random().toString(36).substring(2, 9)}`,
        timestamp: event.timestamp || new Date().toISOString(),
        action: event.action,
        user: event.user,
        ip: event.ip,
        details: event.details || null
      });
    }
  });

  try {
    insertMany(events);
    
    // 2. ANALYZE
    // Run the detection engine on the full event stream and save the resulting incident
    const allEventsStmt = db.prepare('SELECT * FROM events ORDER BY created_at ASC');
    const allEvents = allEventsStmt.all();
    
    const incident = SecurityAnalyzer.analyze(allEvents as any[]);
    
    const insertIncident = db.prepare(`
      INSERT OR REPLACE INTO incidents (id, title, severity, confidence, riskScore, status, data)
      VALUES (@id, @title, @severity, @confidence, @riskScore, @status, @data)
    `);
    
    insertIncident.run({
      id: incident.id,
      title: incident.title,
      severity: incident.severity,
      confidence: incident.confidence,
      riskScore: incident.riskScore,
      status: incident.status,
      data: JSON.stringify(incident)
    });

    res.status(202).json({ success: true, message: `Ingested ${events.length} events, generated incident: ${incident.id}` });
  } catch (error) {
    console.error("Ingestion error:", error);
    res.status(500).json({ error: "Failed to ingest telemetry" });
  }
});

// GET /api/events - retrieve the raw event stream
app.get('/api/events', (req, res) => {
  const stmt = db.prepare('SELECT * FROM events ORDER BY created_at ASC');
  const events = stmt.all();
  res.json(events);
});

// GET /api/incidents/latest - retrieve the latest processed incident
app.get('/api/incidents/latest', (req, res) => {
  const stmt = db.prepare('SELECT * FROM incidents ORDER BY created_at DESC LIMIT 1');
  const record = stmt.get() as { data: string } | undefined;
  
  if (record) {
    res.json(JSON.parse(record.data));
  } else {
    // Return empty state if no telemetry
    res.json(SecurityAnalyzer.createAwaitingTelemetry());
  }
});

// GET /api/incidents - retrieve all incidents
app.get('/api/incidents', (req, res) => {
  const stmt = db.prepare('SELECT * FROM incidents ORDER BY created_at DESC');
  const records = stmt.all() as { data: string }[];
  const incidents = records.map(r => JSON.parse(r.data));
  res.json(incidents);
});

// GET /api/health
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', version: '2.0.0' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`CyberSentinel Backend running on http://localhost:${PORT}`);
});
