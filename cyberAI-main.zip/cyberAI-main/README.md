# CyberSentinel AI

**CyberSentinel AI is a full-stack SOC platform prototype with persistent telemetry, API-based ingestion, deterministic simulation, explainable threat analysis, and human-approved response workflows.**

CyberSentinel AI operates in two distinct modes:
- **Demo Mode**: 100% deterministic, in-browser analysis using `AttackSimulator`.
- **Live SOC Mode**: Real telemetry ingested via an Express API, normalized, persisted to SQLite, and assessed by the core detection engine.

## 🏆 Hackathon MVP Features

- **Deterministic Attack Simulation:** Replay dynamic scenarios (like `GOLDEN_DEMO` or `LATERAL_MOVEMENT`) to validate the engine in real-time.
- **Evidence Provenance:** The engine doesn't just guess. Every piece of evidence explicitly maps back to real `sourceEventIds` from the raw telemetry stream.
- **MITRE ATT&CK Mapping:** Automatically maps correlated anomalous behavior to standardized MITRE techniques.
- **Human-in-the-Loop (HitL) Approvals:** Automated containment simulations strictly require Analyst `APPROVE` or `REJECT` actions before execution.
- **Immutable Audit Trail:** All system analysis, analyst decisions, and containment executions are logged in a timestamped audit trail.

## 🏗 Architecture

The application is built using a unidirectional data flow to guarantee a reliable, testable pipeline.

```text
[ Raw Telemetry / Attack Simulator ]
                │
                ▼
      [ Security Analyzer ]
   (Rules, Correlation, MITRE)
                │
                ▼
      [ Incident Object ]
 (Risk Score, Confidence, Evidence)
                │
                ▼
        [ React App UI ]
  (Live Timeline, Evidence Explorer)
                │
                ▼
[ Human-in-the-Loop Decision Gate ]
                │
           APPROVE / REJECT
                │
                ▼
[ Simulated Response & Audit Trail ]
```

### Core Domain Files
*   `App.tsx` - Core presentation, state management, and HitL logic.
*   `types/security.ts` - Strict TypeScript domain models.
*   `data/scenarios.ts` - Static fallback scenarios.
*   `simulation/AttackSimulator.ts` - Generative telemetry creator.
*   `engine/Analyzer.ts` - Deterministic security analysis engine with explainable risk scoring and MITRE mapping.

## 🧪 Testing & Validation

The architecture's integrity is verified via a hyper-focused Vitest suite (`tests/security.test.tsx`). The test suite features 10 automated constraints validated by the Vitest test suite:

1. `GOLDEN_DEMO` is perfectly deterministic.
2. 3 failed logins + success yields Compromised Credentials evidence.
3. Privilege escalation mathematically increases the risk score.
4. Sensitive file access mathematically increases the risk score.
5. The full `GOLDEN_DEMO` loop definitively yields a Risk >= 85 and a `CRITICAL` severity state.
6. Evidence provenance strictly maps to real source event IDs.
7. Human `APPROVE` executes the simulated containment action and updates the audit log.
8. Human `REJECT` strictly prevents simulated containment.
9. Malformed telemetry triggers a graceful `FAILURE` state instead of crashing.
10. Isolated events without context correctly result in an `INSUFFICIENT_EVIDENCE` state rather than false positives.

**To run the test suite:**
```bash
npm run test
```

## 🎬 The "Golden Demo" Script (Hackathon Pitch)

To properly demonstrate the platform to judges, follow this flow:

1. Launch CyberSentinel AI
2. Select GOLDEN_DEMO
3. Replay telemetry
4. Show correlated attack chain
5. Show evidence + provenance
6. Show Risk / Confidence / MITRE
7. Show Human Approval → Execute
8. Show Audit Trail

## 🚀 Getting Started

```bash
# Install dependencies
npm install

# Run the development server
npm run dev

# Run the test suite
npm run test

# Build for production
npm run build
```
