export type SecurityEvent = {
  id: string;
  timestamp: string;
  action: string;
  user: string;
  ip: string;
  details?: string;
};

export type Evidence = {
  text: string;
  score: number;
  sourceEventIds: string[];
};

export type MitreTechnique = {
  id: string;
  name: string;
  details: string;
  evidence: string;
};

export type ResponseAction = {
  id: string;
  text: string;
  selected: boolean;
};

export type AuditEntry = {
  timestamp: string;
  actor: "AI" | "ANALYST" | "SYSTEM";
  event: string;
  details: string;
};

export type DecisionState = "BENIGN" | "MONITOR" | "INVESTIGATE" | "CONTAIN" | "CRITICAL" | "INSUFFICIENT_EVIDENCE";

export interface Incident {
  id: string;
  title: string;
  severity: DecisionState | "FAILURE" | "AWAITING_TELEMETRY";
  confidence: number;
  riskScore: number;
  status: "NEW" | "INVESTIGATING" | "CONTAINED" | "RESOLVED" | "ROLLED_BACK";
  events: (SecurityEvent & { isAlert?: boolean })[];
  evidence: Evidence[];
  mitreTechniques: MitreTechnique[];
  recommendations: ResponseAction[];
  auditTrail: AuditEntry[];
  attackPattern: string[];
  timeline: { time: string; event: string }[];
  summary: string;
}
