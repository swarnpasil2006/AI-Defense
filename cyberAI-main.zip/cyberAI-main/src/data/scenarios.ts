import type { SecurityEvent } from "../types/security";

export const RAW_SCENARIOS: Record<string, { name: string, events: SecurityEvent[] }> = {
  normal: {
    name: "Scenario 1 - Normal",
    events: [
      { id: "1", timestamp: "10:41:00", action: "LOGIN_PAGE_LOAD", user: "-", ip: "192.168.1.20" },
      { id: "2", timestamp: "10:41:02", action: "LOGIN_SUCCESS", user: "j.smith", ip: "192.168.1.20" },
      { id: "3", timestamp: "10:41:05", action: "ACCESS_RESOURCE", user: "j.smith", ip: "192.168.1.20", details: "Dashboard" }
    ]
  },
  credential: {
    name: "Scenario 2 - Credential Attack",
    events: [
      { id: "4", timestamp: "10:41:02", action: "LOGIN_FAIL", user: "admin", ip: "45.22.91.13" },
      { id: "5", timestamp: "10:41:04", action: "LOGIN_FAIL", user: "admin", ip: "45.22.91.13" },
      { id: "6", timestamp: "10:41:05", action: "LOGIN_FAIL", user: "admin", ip: "45.22.91.13" },
      { id: "7", timestamp: "10:41:07", action: "LOGIN_FAIL", user: "admin", ip: "45.22.91.13" },
      { id: "8", timestamp: "10:41:09", action: "LOGIN_SUCCESS", user: "admin", ip: "45.22.91.13" },
      { id: "9", timestamp: "10:41:12", action: "PRIV_ESC", user: "admin", ip: "45.22.91.13" },
      { id: "10", timestamp: "10:41:18", action: "FILE_ACCESS", user: "admin", ip: "45.22.91.13", details: "/etc/passwd" }
    ]
  },
  privilege: {
    name: "Scenario 3 - Privilege Abuse",
    events: [
      { id: "11", timestamp: "11:20:00", action: "LOGIN_SUCCESS", user: "dev_user", ip: "192.168.1.55" },
      { id: "12", timestamp: "11:25:10", action: "ROLE_CHANGE", user: "dev_user", ip: "192.168.1.55", details: "Role: Admin" },
      { id: "13", timestamp: "11:26:05", action: "DB_DUMP", user: "dev_user", ip: "192.168.1.55", details: "customers_prod" }
    ]
  },
  failure: {
    name: "Scenario 4 - Failure / Unknown",
    events: [
      { id: "14", timestamp: "14:01:00", action: "UNKNOWN_OP", user: "?", ip: "?" },
      { id: "15", timestamp: "14:01:10", action: "ERR_LOG_FMT", user: "?", ip: "?" }
    ]
  },
  adversarial: {
    name: "Scenario 5 - Adversarial Evasion",
    events: [
      { id: "16", timestamp: "08:00:00", action: "LOGIN_SUCCESS", user: "service_acc", ip: "10.0.0.5" },
      { id: "17", timestamp: "09:15:00", action: "FILE_READ", user: "service_acc", ip: "10.0.0.5", details: "config.json" },
      { id: "18", timestamp: "11:40:00", action: "LOGIN_SUCCESS", user: "service_acc", ip: "10.0.0.5" },
      { id: "19", timestamp: "11:55:00", action: "SCHED_TASK", user: "service_acc", ip: "10.0.0.5", details: "sync_job" },
      { id: "20", timestamp: "12:10:00", action: "NET_CONN", user: "service_acc", ip: "10.0.0.5", details: "Outbound to 185.12.x.x" }
    ]
  }
};
