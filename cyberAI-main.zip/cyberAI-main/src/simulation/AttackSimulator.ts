import type { SecurityEvent } from "../types/security";

export class AttackSimulator {
  private static generateId() {
    return Math.random().toString(36).substring(2, 9);
  }

  static generate(pattern: "CREDENTIAL_COMPROMISE" | "INSIDER_THREAT" | "LATERAL_MOVEMENT" | "NORMAL_TRAFFIC" | "GOLDEN_DEMO" | "INSUFFICIENT_DEMO"): SecurityEvent[] {
    const events: SecurityEvent[] = [];
    const baseTime = new Date();
    
    const addEvent = (action: string, user: string, ip: string, details?: string, secondsOffset: number = 0) => {
      baseTime.setSeconds(baseTime.getSeconds() + secondsOffset);
      events.push({
        id: `evt-${this.generateId()}`,
        timestamp: baseTime.toLocaleTimeString('en-US', { hour12: false }),
        action,
        user,
        ip,
        details
      });
    };

    switch (pattern) {
      case "GOLDEN_DEMO":
        addEvent("LOGIN_FAIL", "admin", "185.22.x.x");
        addEvent("LOGIN_FAIL", "admin", "185.22.x.x", undefined, 2);
        addEvent("LOGIN_FAIL", "admin", "185.22.x.x", undefined, 3);
        addEvent("LOGIN_FAIL", "admin", "185.22.x.x", undefined, 2);
        addEvent("LOGIN_SUCCESS", "admin", "185.22.x.x", undefined, 5);
        addEvent("PRIV_ESC", "admin", "185.22.x.x", "Added to Domain Admins", 10);
        addEvent("FILE_ACCESS", "admin", "185.22.x.x", "/etc/shadow", 15);
        break;

      case "INSUFFICIENT_DEMO":
        addEvent("LOGIN_SUCCESS", "j.smith", "10.0.0.99");
        addEvent("PRIV_ESC", "j.smith", "10.0.0.99", "Role change without context", 10);
        break;

      case "CREDENTIAL_COMPROMISE":
        addEvent("LOGIN_FAIL", "admin", "185.22.x.x");
        addEvent("LOGIN_FAIL", "admin", "185.22.x.x", undefined, 2);
        addEvent("LOGIN_FAIL", "admin", "185.22.x.x", undefined, 3);
        addEvent("LOGIN_FAIL", "admin", "185.22.x.x", undefined, 2);
        addEvent("LOGIN_SUCCESS", "admin", "185.22.x.x", undefined, 5);
        addEvent("PRIV_ESC", "admin", "185.22.x.x", "Added to Domain Admins", 10);
        addEvent("FILE_ACCESS", "admin", "185.22.x.x", "/etc/shadow", 15);
        break;

      case "INSIDER_THREAT":
        addEvent("LOGIN_SUCCESS", "dev_user", "10.0.0.12");
        addEvent("FILE_ACCESS", "dev_user", "10.0.0.12", "HR_Salaries.xlsx", 30);
        addEvent("DB_DUMP", "dev_user", "10.0.0.12", "Production DB", 60);
        addEvent("NET_CONN", "dev_user", "10.0.0.12", "Outbound to Mega (Cloud Storage)", 15);
        break;

      case "LATERAL_MOVEMENT":
        addEvent("LOGIN_SUCCESS", "svc_account", "10.0.0.5");
        addEvent("SCHED_TASK", "svc_account", "10.0.0.5", "Create Reverse Shell", 120);
        addEvent("LOGIN_SUCCESS", "svc_account", "10.0.0.8", "Moved to DB Server", 100);
        addEvent("PRIV_ESC", "svc_account", "10.0.0.8", "SYSTEM exploit", 60);
        break;

      case "NORMAL_TRAFFIC":
      default:
        addEvent("LOGIN_PAGE_LOAD", "-", "192.168.1.100");
        addEvent("LOGIN_SUCCESS", "j.smith", "192.168.1.100", undefined, 5);
        addEvent("ACCESS_RESOURCE", "j.smith", "192.168.1.100", "Dashboard", 2);
        addEvent("ACCESS_RESOURCE", "j.smith", "192.168.1.100", "Email", 60);
        break;
    }

    return events;
  }
}
