import type { SecurityEvent, Incident, Evidence, MitreTechnique, ResponseAction, DecisionState, AuditEntry } from "../types/security";

export class SecurityAnalyzer {
  static analyze(events: SecurityEvent[]): Incident {
    const auditTrail: AuditEntry[] = [];
    
    // Add raw events to system audit
    if (events.length > 0) {
      auditTrail.push({ 
        timestamp: events[events.length - 1].timestamp || new Date().toLocaleTimeString(), 
        actor: "SYSTEM", 
        event: "Telemetry Received", 
        details: `Processed batch of ${events.length} event(s)` 
      });
    }

    // 1. VALIDATION ENGINE
    if (events.length === 0) {
      return this.createAwaitingTelemetry();
    }
    
    const hasInvalidEvents = events.some(e => !e.action || !e.timestamp || e.action.includes("UNKNOWN") || e.action.includes("ERR"));
    if (hasInvalidEvents || events.length < 2) {
       return this.createFailure("Insufficient or malformed telemetry context. Cannot confidently establish baseline.", events);
    }

    // 2. CORRELATION & RULE ENGINE (Simplified single-pass)
    let riskScore = 0;
    let confidence = 0;
    const evidence: Evidence[] = [];
    const mitreTechniques: MitreTechnique[] = [];
    const attackPattern: string[] = [];
    const timeline: { time: string; event: string }[] = [];
    const flaggedEvents = [...events] as (SecurityEvent & { isAlert?: boolean })[];
    
    // Trackers
    const failedLoginEvents = events.filter(e => e.action === "LOGIN_FAIL");
    const successLoginEvents = events.filter(e => e.action === "LOGIN_SUCCESS");
    const privEscEvents = events.filter(e => e.action === "PRIV_ESC" || e.action === "ROLE_CHANGE");
    const fileAccessEvents = events.filter(e => e.action === "FILE_ACCESS" || e.action === "DB_DUMP");
    const unknownIpEvents = events.filter(e => e.ip !== "192.168.1.20" && e.ip !== "10.0.0.5" && e.ip !== "127.0.0.1");
    const schedTaskEvents = events.filter(e => e.action === "SCHED_TASK");

    events.forEach(e => timeline.push({ time: e.timestamp, event: e.action }));

    // Rule 1: Brute Force
    if (failedLoginEvents.length > 3) {
      riskScore += 20;
      evidence.push({ text: `Multiple failed logins (${failedLoginEvents.length})`, score: 20, sourceEventIds: failedLoginEvents.map(e => e.id) });
      mitreTechniques.push({ id: "T1110", name: "Brute Force", details: "Multiple authentication failures.", evidence: `${failedLoginEvents.length} failed attempts detected.` });
      attackPattern.push("Credential Attack");
      flaggedEvents.forEach(e => { if(e.action === "LOGIN_FAIL") e.isAlert = true; });
      auditTrail.push({ timestamp: new Date().toLocaleTimeString(), actor: "AI", event: "Pattern Detected", details: "Brute-force pattern identified (+20 Risk)" });
    }

    // Rule 2: Unknown IP
    if (unknownIpEvents.length > 0) {
      riskScore += 15;
      evidence.push({ text: "Unknown source IP", score: 15, sourceEventIds: unknownIpEvents.map(e => e.id) });
    }

    // Rule 3: Compromised Credentials (Success after fail)
    if (failedLoginEvents.length > 0 && successLoginEvents.length > 0) {
      riskScore += 25;
      confidence += 40;
      evidence.push({ text: "Successful login after failures", score: 25, sourceEventIds: [...failedLoginEvents.map(e=>e.id), ...successLoginEvents.map(e=>e.id)] });
      attackPattern.push("Initial Access");
      flaggedEvents.forEach(e => { if(e.action === "LOGIN_SUCCESS") e.isAlert = true; });
      auditTrail.push({ timestamp: new Date().toLocaleTimeString(), actor: "AI", event: "Pattern Detected", details: "Potential account compromise via brute-force (+25 Risk)" });
    }

    // Rule 4: Privilege Escalation
    if (privEscEvents.length > 0) {
      riskScore += 30;
      confidence += 30;
      evidence.push({ text: "Privilege escalation detected", score: 30, sourceEventIds: privEscEvents.map(e => e.id) });
      mitreTechniques.push({ id: "T1068", name: "Privilege Escalation", details: "Adversary attempting to gain higher-level privileges.", evidence: "Role change or privilege escalation event logged." });
      attackPattern.push("Privilege Escalation");
      flaggedEvents.forEach(e => { if(e.action === "PRIV_ESC" || e.action === "ROLE_CHANGE") e.isAlert = true; });
      auditTrail.push({ timestamp: new Date().toLocaleTimeString(), actor: "AI", event: "Anomaly Detected", details: "Unauthorized privilege escalation (+30 Risk)" });
    }

    // Rule 5: Data Access
    if (fileAccessEvents.length > 0) {
      riskScore += 15;
      confidence += 20;
      evidence.push({ text: "Sensitive file/db access", score: 15, sourceEventIds: fileAccessEvents.map(e => e.id) });
      attackPattern.push("Sensitive Resource Access");
      flaggedEvents.forEach(e => { if(e.action === "FILE_ACCESS" || e.action === "DB_DUMP") e.isAlert = true; });
    }

    // Rule 6: Persistence
    if (schedTaskEvents.length > 0) {
      riskScore += 25;
      confidence += 25;
      evidence.push({ text: "Scheduled task creation", score: 25, sourceEventIds: schedTaskEvents.map(e => e.id) });
      mitreTechniques.push({ id: "T1053", name: "Scheduled Task/Job", details: "Abuse task scheduling.", evidence: "Creation of unexpected scheduled task." });
      flaggedEvents.forEach(e => { if(e.action === "SCHED_TASK") e.isAlert = true; });
      auditTrail.push({ timestamp: new Date().toLocaleTimeString(), actor: "AI", event: "Pattern Detected", details: "Persistence mechanism established (+25 Risk)" });
    }

    // 3. DECISION ENGINE
    riskScore = Math.min(riskScore, 100);
    confidence = Math.min(confidence || 50, 99);
    
    let severity: DecisionState;
    let title = "";
    let summary = "";

    if (riskScore === 0) {
       riskScore = 8;
       confidence = 99;
    }

    if (riskScore >= 80) {
      severity = "CRITICAL";
      title = "Critical Compromise Detected";
      summary = "High confidence of a multi-stage attack based on correlated events.";
    } else if (riskScore >= 60) {
      severity = "CONTAIN";
      title = "High Risk Activity";
      summary = "Anomalous behavior requires immediate containment.";
    } else if (riskScore >= 40 && confidence > 35) {
      severity = "INVESTIGATE";
      title = "Suspicious Pattern";
      summary = "Deviation from baseline warrants manual investigation.";
    } else if (riskScore > 20 && confidence <= 35) {
      severity = "INSUFFICIENT_EVIDENCE";
      title = "Insufficient Evidence";
      summary = "Suspicious event observed, but lacks context (e.g. no preceding authentication).";
    } else if (riskScore >= 20) {
      severity = "MONITOR";
      title = "Low Anomaly";
      summary = "Minor deviations detected. Continuing to monitor.";
    } else {
      severity = "BENIGN";
      title = "System Normal";
      summary = "Activity matches expected baseline behavior.";
    }

    auditTrail.push({ timestamp: new Date().toLocaleTimeString(), actor: "AI", event: "Decision Computed", details: `Calculated Risk: ${riskScore}/100. State: ${severity}` });

    // 4. RESPONSE ENGINE
    const recommendations: ResponseAction[] = [];
    if (severity === "CRITICAL" || severity === "CONTAIN") {
       recommendations.push(
         { id: "r1", text: "Temporarily lock affected account", selected: true },
         { id: "r2", text: "Isolate endpoint", selected: true },
         { id: "r3", text: "Force credential reset", selected: true }
       );
       auditTrail.push({ timestamp: new Date().toLocaleTimeString(), actor: "AI", event: "Action Recommended", details: "Recommended ISOLATE_ENDPOINT and LOCK_ACCOUNT" });
    } else if (severity === "INVESTIGATE") {
       recommendations.push(
         { id: "r1", text: "Review recent activity logs", selected: true },
         { id: "r2", text: "Block unknown IP addresses", selected: false }
       );
    } else if (severity === "MONITOR") {
       recommendations.push({ id: "r1", text: "Add user to high-risk watchlist", selected: true });
    }

    return {
      id: `INC-${Math.floor(Math.random() * 10000)}`,
      title,
      severity,
      confidence,
      riskScore,
      status: "NEW",
      events: flaggedEvents,
      evidence,
      mitreTechniques,
      recommendations,
      attackPattern,
      timeline,
      summary,
      auditTrail
    };
  }

  private static createAwaitingTelemetry(): Incident {
    return {
      id: `INC-WAIT`,
      title: "Awaiting Telemetry",
      severity: "AWAITING_TELEMETRY",
      confidence: 0,
      riskScore: 0,
      status: "NEW",
      events: [],
      evidence: [],
      mitreTechniques: [],
      recommendations: [],
      auditTrail: [],
      attackPattern: [],
      timeline: [],
      summary: "Ready to process event stream."
    };
  }

  private static createFailure(reason: string, events: SecurityEvent[]): Incident {
    return {
      id: `INC-ERR-${Math.floor(Math.random() * 1000)}`,
      title: "Insufficient Evidence",
      severity: "FAILURE",
      confidence: 21,
      riskScore: 21,
      status: "NEW",
      events: events,
      evidence: [{ text: "Context validation failed", score: 5, sourceEventIds: events.map(e => e.id) }],
      mitreTechniques: [],
      recommendations: [{ id: "r1", text: "Request manual analyst review", selected: true }],
      auditTrail: [
        { timestamp: new Date().toLocaleTimeString(), actor: "SYSTEM", event: "Validation Failed", details: reason }
      ],
      attackPattern: [],
      timeline: events.map(e => ({ time: e.timestamp || "Unknown", event: e.action || "Unknown" })),
      summary: reason
    };
  }
}
