import { useState, useEffect, useRef } from 'react';
import { Shield, ShieldAlert, Activity, GitCommit, FileText, CheckCircle, Eye, Terminal, Lock, UploadCloud, Play, Square, XCircle, RefreshCw, ChevronRight, List, LayoutDashboard, Search, Filter } from 'lucide-react';
import { RAW_SCENARIOS } from './data/scenarios';
import { SecurityAnalyzer } from './engine/Analyzer';
import { AttackSimulator } from './simulation/AttackSimulator';
import type { Incident, SecurityEvent, AuditEntry } from './types/security';

export default function App() {
  const getFullEventStream = (scenarioKey: string) => {
    if (scenarioKey === 'custom' && customEvents) return customEvents;
    if (scenarioKey.startsWith('sim:')) {
      const simType = scenarioKey.split(':')[1] as any;
      return AttackSimulator.generate(simType);
    }
    return RAW_SCENARIOS[scenarioKey]?.events || [];
  };

  const [activeScenarioKey, setActiveScenarioKey] = useState<string>('sim:GOLDEN_DEMO');
  const [customEvents, setCustomEvents] = useState<SecurityEvent[] | null>(null);
  
  // Initialize synchronously to avoid "Initializing engine..." flash or getting stuck
  const [incident, setIncident] = useState<Incident>(() => {
    return SecurityAnalyzer.analyze([]);
  });
  
  const [responseStatus, setResponseStatus] = useState<'pending' | 'approved' | 'rejected' | 'rolled-back'>('pending');
  const [localAudit, setLocalAudit] = useState<AuditEntry[]>(incident.auditTrail);
  
  const [showLogPaster, setShowLogPaster] = useState(false);
  const [rawLogsText, setRawLogsText] = useState("");
  
  const [isReplaying, setIsReplaying] = useState(false);
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'incidents'>('dashboard');
  const [incidentList, setIncidentList] = useState<Incident[]>([]);
  
  const replayTimerRef = useRef<number | null>(null);

  const startReplay = () => {
    setIsLiveMode(false);
    setIsReplaying(true);
    
    // Clear incident to "empty" state while we wait for first event
    const emptyIncident = SecurityAnalyzer.analyze([]);
    setIncident(emptyIncident);
    setLocalAudit([]);
  };

  const stopReplay = () => {
    setIsReplaying(false);
    if (replayTimerRef.current) clearInterval(replayTimerRef.current);
    const fullStream = getFullEventStream(activeScenarioKey);
    const inc = SecurityAnalyzer.analyze(fullStream);
    setIncident(inc);
    setLocalAudit(inc.auditTrail);
  };

  const resetIncident = () => {
    setIsReplaying(false);
    setIsLiveMode(false);
    if (replayTimerRef.current) clearInterval(replayTimerRef.current);
    
    // Set to empty state
    const emptyIncident = SecurityAnalyzer.analyze([]);
    setIncident(emptyIncident);
    setLocalAudit([]);
    setResponseStatus('pending');
  };

  // Replay Effect
  useEffect(() => {
    if (isReplaying) {
      const fullStream = getFullEventStream(activeScenarioKey);
      let currentIndex = 0;
      
      replayTimerRef.current = window.setInterval(() => {
        if (currentIndex >= fullStream.length) {
          setIsReplaying(false);
          return;
        }
        
        const currentSlice = fullStream.slice(0, currentIndex + 1);
        const inc = SecurityAnalyzer.analyze(currentSlice);
        setIncident(inc);
        setLocalAudit(inc.auditTrail);
        
        currentIndex++;
      }, 1000);
    }
    
    return () => {
      if (replayTimerRef.current) {
        clearInterval(replayTimerRef.current);
        replayTimerRef.current = null;
      }
    };
  }, [isReplaying, activeScenarioKey, customEvents]);

  // When scenario changes, instantly analyze it
  const handleScenarioChange = (newKey: string) => {
    setActiveScenarioKey(newKey);
    setIsReplaying(false);
    setIsLiveMode(false);
    setResponseStatus('pending');
    
    const fullStream = getFullEventStream(newKey);
    const inc = SecurityAnalyzer.analyze(fullStream);
    setIncident(inc);
    setLocalAudit(inc.auditTrail);
  };

  const startLiveMode = () => {
    setIsReplaying(false);
    setIsLiveMode(true);
    setActiveScenarioKey('live');
    setResponseStatus('pending');
    
    const emptyIncident = SecurityAnalyzer.analyze([]);
    setIncident(emptyIncident);
    setLocalAudit([]);
  };

  // Live Mode Effect
  useEffect(() => {
    if (!isLiveMode) return;

    const pollBackend = async () => {
      try {
        const res = await fetch('http://localhost:3001/api/incidents/latest');
        if (res.ok) {
          const inc = await res.json();
          setIncident(inc);
          setLocalAudit(inc.auditTrail || []);
        }
      } catch (e) {
        console.error("Backend poll failed:", e);
      }
    };

    pollBackend(); // Initial poll
    const interval = setInterval(pollBackend, 2000); // Poll every 2 seconds

    return () => clearInterval(interval);
  }, [isLiveMode]);

  // Fetch all incidents when entering the incident management view
  useEffect(() => {
    if (currentView === 'incidents') {
      const fetchIncidents = async () => {
        try {
          const res = await fetch('http://localhost:3001/api/incidents');
          if (res.ok) {
            const data = await res.json();
            setIncidentList(data);
          }
        } catch (e) {
          console.error("Failed to fetch incidents:", e);
        }
      };
      fetchIncidents();
    }
  }, [currentView]);

  const handleApprove = () => {
    setResponseStatus('approved');
    setLocalAudit(prev => [
      ...prev,
      { timestamp: new Date().toLocaleTimeString(), actor: "ANALYST", event: "Response Approved", details: "Analyst authorized containment plan" },
      { timestamp: new Date().toLocaleTimeString(), actor: "SYSTEM", event: "Simulation Executed", details: "Endpoint isolated and account locked" }
    ]);
  };

  const handleReject = () => {
    setResponseStatus('rejected');
    setLocalAudit(prev => [
      ...prev,
      { timestamp: new Date().toLocaleTimeString(), actor: "ANALYST", event: "Response Rejected", details: "Analyst dismissed recommendation as false positive or unnecessary" }
    ]);
  };

  const handleRollback = () => {
    setResponseStatus('rolled-back');
    setLocalAudit(prev => [
      ...prev,
      { timestamp: new Date().toLocaleTimeString(), actor: "ANALYST", event: "Rollback Initiated", details: "Reverting simulated containment actions" },
      { timestamp: new Date().toLocaleTimeString(), actor: "SYSTEM", event: "Rollback Complete", details: "Endpoint restored to normal network" }
    ]);
  };

  const handlePasteLogs = () => {
    try {
      const parsed = JSON.parse(rawLogsText);
      const events: SecurityEvent[] = Array.isArray(parsed) ? parsed : [parsed];
      setCustomEvents(events);
      setActiveScenarioKey('custom');
      setShowLogPaster(false);
      resetIncident();
    } catch (e) {
      alert("Invalid JSON format. Please paste a valid JSON array of SecurityEvents.");
    }
  };

  if (!incident) return <div className="p-8 text-white font-mono">Initializing engine...</div>;

  const riskColor = 
    incident.riskScore >= 80 ? 'text-rose-500' :
    incident.riskScore >= 50 ? 'text-amber-500' :
    'text-emerald-500';

  const bgRiskColor = 
    incident.riskScore >= 80 ? 'bg-rose-500/10 border-rose-500/30' :
    incident.riskScore >= 50 ? 'bg-amber-500/10 border-amber-500/30' :
    'bg-emerald-500/10 border-emerald-500/30';

  return (
    <div className="min-h-screen bg-bg-dark text-text-main font-sans selection:bg-primary/30 p-4 md:p-6 lg:p-8">
      {/* Header & Navigation */}
      <header className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary/20 border border-primary/50 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight m-0 text-white">CyberSentinel AI</h1>
              <p className="text-sm text-text-muted m-0">Dynamic Evaluation Engine (v2.0)</p>
            </div>
          </div>
          
          {/* Main Navigation */}
          <div className="flex items-center gap-2 bg-bg-panel p-1 rounded-lg border border-border-dark">
            <button 
              onClick={() => setCurrentView('dashboard')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentView === 'dashboard' ? 'bg-bg-dark text-white shadow-sm' : 'text-text-muted hover:text-white'}`}
            >
              <LayoutDashboard className="w-4 h-4" />
              Dashboard
            </button>
            <button 
              onClick={() => setCurrentView('incidents')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentView === 'incidents' ? 'bg-bg-dark text-white shadow-sm' : 'text-text-muted hover:text-white'}`}
            >
              <List className="w-4 h-4" />
              Incidents
            </button>
          </div>
          
          <div className="flex gap-2">
             {!isReplaying ? (
               <button onClick={startReplay} className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-lg text-sm hover:bg-emerald-500/20 transition-colors">
                 <Play className="w-4 h-4" /> Replay Attack
               </button>
             ) : (
               <button onClick={stopReplay} className="flex items-center gap-2 px-4 py-2 bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded-lg text-sm hover:bg-rose-500/20 transition-colors">
                 <Square className="w-4 h-4" /> Stop Replay
               </button>
             )}
            <button 
              onClick={resetIncident}
              className="flex items-center gap-2 px-4 py-2 bg-bg-panel border border-border-dark rounded-lg text-sm hover:border-amber-500 hover:text-amber-500 transition-colors"
            >
              <RefreshCw className="w-4 h-4" /> Reset
            </button>
            <button 
              onClick={() => setShowLogPaster(!showLogPaster)}
              className="flex items-center gap-2 px-4 py-2 bg-bg-panel border border-border-dark rounded-lg text-sm hover:border-primary hover:text-primary transition-colors"
            >
              <UploadCloud className="w-4 h-4" />
              Ingest
            </button>
            <button 
              onClick={startLiveMode}
              className={`flex items-center gap-2 px-4 py-2 border rounded-lg text-sm transition-colors ${
                isLiveMode 
                  ? 'bg-rose-500/20 border-rose-500 text-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.3)] animate-pulse' 
                  : 'bg-bg-panel border-border-dark text-text-muted hover:border-emerald-500 hover:text-emerald-500'
              }`}
            >
              <Activity className="w-4 h-4" />
              {isLiveMode ? 'Live SOC Active' : 'Go Live'}
            </button>
          </div>
        </div>

        {showLogPaster && (
          <div className="mb-6 p-4 bg-bg-panel border border-primary/50 rounded-lg">
            <div className="text-sm text-text-muted mb-2">Paste JSON Array of Events:</div>
            <textarea 
              className="w-full h-32 bg-bg-dark border border-border-dark rounded p-2 text-xs font-mono text-white outline-none focus:border-primary"
              value={rawLogsText}
              onChange={(e) => setRawLogsText(e.target.value)}
            />
            <div className="mt-2 flex gap-2">
              <button onClick={handlePasteLogs} className="px-4 py-1.5 bg-primary text-white text-sm rounded hover:bg-primary-hover">Analyze Logs</button>
              <button onClick={() => setShowLogPaster(false)} className="px-4 py-1.5 border border-border-dark text-sm rounded text-text-muted">Cancel</button>
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <span className="text-xs font-semibold text-text-muted uppercase tracking-wider mr-2">Generative Demos:</span>
          
          {["GOLDEN_DEMO", "INSUFFICIENT_DEMO", "LATERAL_MOVEMENT"].map(sim => (
            <button
              key={`sim:${sim}`}
              onClick={() => handleScenarioChange(`sim:${sim}`)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all duration-300 ${
                activeScenarioKey === `sim:${sim}`
                  ? 'bg-amber-500/20 border-amber-500/50 text-amber-200 shadow-[0_0_15px_rgba(245,158,11,0.2)]' 
                  : 'bg-bg-panel border-border-dark text-text-muted hover:border-text-muted/50 hover:text-amber-200'
              }`}
            >
              {sim.replace('_', ' ')}
            </button>
          ))}
          
          <div className="w-px h-6 bg-border-dark mx-2"></div>
          <span className="text-xs font-semibold text-text-muted uppercase tracking-wider mr-2">Static Scenarios:</span>
          {Object.entries(RAW_SCENARIOS).map(([key, s]) => (
            <button
              key={key}
              onClick={() => handleScenarioChange(key)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all duration-300 ${
                activeScenarioKey === key 
                  ? 'bg-primary/20 border-primary text-white shadow-[0_0_15px_rgba(170,59,255,0.2)]' 
                  : 'bg-bg-panel border-border-dark text-text-muted hover:border-text-muted/50 hover:text-white'
              }`}
            >
              {s.name}
            </button>
          ))}
          
          {customEvents && (
            <button
              onClick={() => handleScenarioChange('custom')}
              className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all duration-300 ${
                activeScenarioKey === 'custom' 
                  ? 'bg-primary/20 border-primary text-white shadow-[0_0_15px_rgba(170,59,255,0.2)]' 
                  : 'bg-bg-panel border-border-dark text-text-muted hover:border-text-muted/50 hover:text-white'
              }`}
            >
              Custom Logs
            </button>
          )}
        </div>
      </header>

      {currentView === 'incidents' ? (
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <List className="w-5 h-5 text-primary" />
              Incident Management
            </h2>
            <div className="flex gap-3">
              <div className="flex items-center gap-2 bg-bg-panel px-3 py-1.5 rounded-lg border border-border-dark">
                <Search className="w-4 h-4 text-text-muted" />
                <input type="text" placeholder="Search incidents..." className="bg-transparent border-none text-sm text-white focus:outline-none w-48" />
              </div>
              <button className="flex items-center gap-2 px-3 py-1.5 bg-bg-panel border border-border-dark rounded-lg text-sm text-text-muted hover:text-white transition-colors">
                <Filter className="w-4 h-4" />
                Filter
              </button>
            </div>
          </div>

          <div className="bg-bg-panel rounded-xl border border-border-dark overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-bg-dark border-b border-border-dark">
                  <th className="p-4 text-xs font-semibold text-text-muted uppercase tracking-wider">Incident ID</th>
                  <th className="p-4 text-xs font-semibold text-text-muted uppercase tracking-wider">Severity</th>
                  <th className="p-4 text-xs font-semibold text-text-muted uppercase tracking-wider">Risk Score</th>
                  <th className="p-4 text-xs font-semibold text-text-muted uppercase tracking-wider">Decision</th>
                  <th className="p-4 text-xs font-semibold text-text-muted uppercase tracking-wider">Title</th>
                  <th className="p-4 text-xs font-semibold text-text-muted uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border-dark">
                {incidentList.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-text-muted">
                      No incidents recorded yet.
                    </td>
                  </tr>
                ) : (
                  incidentList.map((inc) => (
                    <tr key={inc.id} className="hover:bg-bg-dark/50 transition-colors">
                      <td className="p-4 font-mono text-sm text-white">{inc.id}</td>
                      <td className="p-4">
                        <span className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${
                          inc.severity === 'CRITICAL' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                          inc.severity === 'HIGH' ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' :
                          'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        }`}>
                          {inc.severity.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-2 bg-bg-dark rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${inc.riskScore > 80 ? 'bg-rose-500' : inc.riskScore > 50 ? 'bg-amber-500' : 'bg-emerald-500'}`} 
                              style={{ width: `${inc.riskScore}%` }}
                            />
                          </div>
                          <span className="text-sm text-white">{inc.riskScore}</span>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${
                          inc.status === 'CONTAIN' || inc.status === 'ISOLATE' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                          'bg-bg-dark text-text-muted border border-border-dark'
                        }`}>
                          {inc.status}
                        </span>
                      </td>
                      <td className="p-4 text-sm text-white truncate max-w-xs">{inc.title}</td>
                      <td className="p-4">
                        <button 
                          onClick={() => {
                            setIncident(inc);
                            setLocalAudit(inc.auditTrail || []);
                            setCurrentView('dashboard');
                          }}
                          className="text-primary hover:text-primary-light text-sm font-medium transition-colors"
                        >
                          Investigate
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <main className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Telemetry & Timeline */}
        <div className="lg:col-span-4 space-y-6 flex flex-col">
          
          <section className="bg-bg-panel border border-border-dark rounded-xl p-5 shadow-lg flex-1">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-white flex items-center gap-2 m-0">
                <Activity className="w-5 h-5 text-emerald-400" />
                Live Security Telemetry
              </h2>
              <span className={`text-xs px-2 py-1 rounded border ${isLiveMode ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'}`}>
                {isLiveMode ? "LIVE BACKEND" : isReplaying ? "REPLAYING..." : "DEMO MODE"}
              </span>
            </div>
            
            <div className="font-mono text-xs md:text-sm space-y-2 max-h-[300px] overflow-y-auto pr-2">
              {incident.events.map((log) => (
                <div key={log.id} className={`flex gap-3 p-2 rounded ${log.isAlert ? 'bg-rose-500/10 text-rose-300' : 'text-text-muted'}`}>
                  <span className="opacity-70 shrink-0">{log.timestamp}</span>
                  <span className="font-semibold w-28 shrink-0">{log.action}</span>
                  <span className="truncate">usr={log.user} src={log.ip}</span>
                </div>
              ))}
              {incident.events.length === 0 && <div className="text-text-muted text-center pt-8">Awaiting telemetry...</div>}
            </div>
          </section>

          <section className="bg-bg-panel border border-border-dark rounded-xl p-5 shadow-lg flex-1">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-6 m-0">
              <GitCommit className="w-5 h-5 text-primary" />
              Attack Story & Timeline
            </h2>
            
            <div className="space-y-6 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-border-dark before:to-transparent">
              {incident.timeline.map((item, i) => (
                <div key={i} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-bg-panel bg-primary/20 text-primary shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                    <span className="w-2 h-2 bg-primary rounded-full"></span>
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-bg-dark p-3 rounded border border-border-dark shadow">
                    <div className="text-xs text-text-muted mb-1">{item.time}</div>
                    <div className="text-sm font-medium text-white">{item.event}</div>
                  </div>
                </div>
              ))}
            </div>
            
            {incident.attackPattern.length > 0 && (
               <div className="mt-8 p-4 bg-bg-dark border border-border-dark rounded-lg animate-in fade-in slide-in-from-bottom-2 duration-500">
                <div className="text-xs font-semibold text-text-muted uppercase tracking-wider mb-3">Predicted Attack Path</div>
                <div className="flex flex-wrap items-center gap-2 text-sm">
                  {incident.attackPattern.map((step, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-white bg-primary/20 px-2 py-1 rounded border border-primary/30">{step}</span>
                      {i < incident.attackPattern.length - 1 && <span className="text-text-muted">→</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        </div>

        {/* CENTER & RIGHT COLUMN */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          
          <section className={`border rounded-xl p-6 shadow-lg transition-colors duration-500 ${bgRiskColor}`}>
            <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <ShieldAlert className={`w-6 h-6 ${riskColor}`} />
                  <span className={`text-sm font-bold uppercase tracking-wider ${riskColor}`}>
                    {incident.severity.replace('_', ' ')}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">{incident.title}</h2>
                <p className="text-text-muted max-w-2xl leading-relaxed">
                  <span className="font-semibold text-white">AI Assessment: </span>
                  {incident.summary}
                </p>
              </div>

              <div className="flex gap-4 shrink-0 bg-bg-dark p-4 rounded-lg border border-border-dark shadow-inner">
                <div className="text-center">
                  <div className={`text-3xl font-bold transition-all duration-500 ${riskColor}`}>{incident.severity === 'AWAITING_TELEMETRY' ? '—' : incident.riskScore}</div>
                  <div className="text-xs text-text-muted uppercase font-semibold mt-1">Risk Score</div>
                </div>
                <div className="w-px bg-border-dark"></div>
                <div className="text-center">
                  <div className={`text-3xl font-bold transition-all duration-500 ${incident.confidence >= 80 ? 'text-emerald-400' : incident.confidence < 40 ? 'text-rose-400' : 'text-amber-400'}`}>{incident.severity === 'AWAITING_TELEMETRY' ? '—' : `${incident.confidence}%`}</div>
                  <div className="text-xs text-text-muted uppercase font-semibold mt-1">Confidence</div>
                </div>
              </div>
            </div>
          </section>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <section className="bg-bg-panel border border-border-dark rounded-xl p-5 shadow-lg">
              <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4 m-0">
                <Eye className="w-5 h-5 text-primary" />
                Evidence Explorer
              </h2>
              
              {incident.evidence.length > 0 ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-1 text-[10px] text-primary uppercase font-bold tracking-wider mb-4 border border-primary/20 bg-primary/10 p-2 rounded">
                    <span>RAW EVENT</span><ChevronRight className="w-3 h-3"/>
                    <span>RULE</span><ChevronRight className="w-3 h-3"/>
                    <span>RISK</span><ChevronRight className="w-3 h-3"/>
                    <span>MITRE</span><ChevronRight className="w-3 h-3"/>
                    <span>DECISION</span>
                  </div>

                  <div className="flex justify-between text-xs font-semibold text-text-muted uppercase pb-2 border-b border-border-dark">
                    <span>Evidence Factor</span>
                    <span>Risk Contribution</span>
                  </div>
                  {incident.evidence.map((ev, i) => (
                    <div key={i} className="flex justify-between items-center bg-bg-dark p-2 rounded border border-border-dark/50 group relative cursor-pointer">
                      <div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-3 h-3 text-primary" />
                          <span className="text-sm text-gray-300 block">{ev.text}</span>
                        </div>
                        <span className="text-[10px] text-text-muted pl-5">Provenance: {ev.sourceEventIds.length} event(s) mapped</span>
                      </div>
                      <span className="text-sm font-mono font-medium text-rose-400">+{ev.score}</span>
                      
                      {/* Tooltip for provenance */}
                      <div className="absolute right-0 bottom-full mb-2 w-64 bg-black border border-border-dark p-3 rounded shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                        <div className="text-xs text-gray-400 mb-2">Why is this evidence included?</div>
                        <div className="text-[10px] text-primary uppercase mb-1">Source Event IDs:</div>
                        <div className="font-mono text-[10px] text-white flex flex-col gap-1">
                          {ev.sourceEventIds.map(id => (
                            <div key={id} className="bg-gray-800 px-2 py-1 rounded truncate flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span> {id}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                  <div className="flex justify-between items-center pt-3 border-t border-border-dark">
                    <span className="font-semibold text-white">Total Risk Score</span>
                    <span className="font-mono font-bold text-lg text-white">{incident.riskScore}</span>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-text-muted">
                  <CheckCircle className="w-8 h-8 mx-auto mb-2 opacity-50 text-emerald-500" />
                  <p>No anomalous evidence detected.</p>
                </div>
              )}
            </section>

            <section className="bg-bg-panel border border-border-dark rounded-xl p-5 shadow-lg">
              <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4 m-0">
                <Terminal className="w-5 h-5 text-primary" />
                MITRE ATT&CK Mapping
              </h2>

              {incident.mitreTechniques.length > 0 ? (
                <div className="space-y-4 overflow-y-auto max-h-[300px] pr-2">
                  {incident.mitreTechniques.map((m, i) => (
                    <div key={i} className="bg-bg-dark p-3 rounded-lg border border-border-dark group">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="bg-primary/20 text-primary text-xs font-mono px-1.5 py-0.5 rounded border border-primary/30">
                          {m.id}
                        </span>
                        <span className="font-semibold text-sm text-white">{m.name}</span>
                      </div>
                      <p className="text-xs text-text-muted mb-2">{m.details}</p>
                      <div className="text-xs bg-bg-panel p-2 rounded border border-border-dark border-l-2 border-l-rose-500 text-gray-300">
                        <span className="font-semibold block mb-1">Local Evidence:</span>
                        {m.evidence}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-text-muted">
                  <p>No ATT&CK techniques mapped.</p>
                </div>
              )}
            </section>
          </div>

          {incident.severity !== 'BENIGN' && incident.severity !== 'FAILURE' && incident.severity !== 'INSUFFICIENT_EVIDENCE' && incident.severity !== 'AWAITING_TELEMETRY' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <section className="bg-bg-panel border border-border-dark rounded-xl p-5 shadow-lg flex flex-col">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4 m-0">
                  <Lock className="w-5 h-5 text-primary" />
                  Human-in-the-Loop Response
                </h2>
                
                <div className="flex-1">
                  <div className="text-sm font-medium text-rose-400 mb-3 uppercase tracking-wider">AI Recommended Plan</div>
                  <div className="space-y-2 mb-6">
                    {incident.recommendations.map((rec) => (
                      <label key={rec.id} className="flex items-start gap-3 p-2 bg-bg-dark rounded border border-border-dark cursor-pointer">
                        <input type="checkbox" defaultChecked={rec.selected} className="mt-1 accent-primary" />
                        <span className="text-sm text-gray-300">{rec.text}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-border-dark">
                  {responseStatus === 'pending' ? (
                    <div className="bg-bg-dark border border-border-dark p-4 rounded-lg">
                      <div className="text-xs font-bold uppercase text-amber-500 mb-2">Human Approval Required</div>
                      <div className="flex gap-2">
                        <button 
                          onClick={handleApprove}
                          className="flex-1 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/50 rounded text-sm font-semibold transition-colors"
                        >
                          APPROVE
                        </button>
                        <button 
                          onClick={handleReject}
                          className="flex-1 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded text-sm font-semibold transition-colors"
                        >
                          REJECT
                        </button>
                      </div>
                    </div>
                  ) : responseStatus === 'approved' ? (
                    <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                      <div className="flex items-center gap-2 text-emerald-400 mb-3 font-semibold">
                        <CheckCircle className="w-5 h-5" />
                        Simulation Executed
                      </div>
                      <ul className="text-sm text-emerald-300/80 space-y-1 mb-4 list-disc pl-5">
                        <li>Actions applied successfully</li>
                        <li>Incident {incident.id} updated</li>
                        <li>Analyst on-call notified</li>
                      </ul>
                      <button 
                        onClick={handleRollback}
                        className="text-xs text-text-muted hover:text-white underline underline-offset-2 transition-colors"
                      >
                        Rollback Actions
                      </button>
                    </div>
                  ) : responseStatus === 'rejected' ? (
                     <div className="bg-bg-dark border border-border-dark rounded-lg p-4 text-center">
                      <div className="text-text-muted font-semibold mb-2 flex items-center justify-center gap-2">
                        <XCircle className="w-4 h-4 text-rose-500"/>
                        Analyst Rejected Recommendation
                      </div>
                      <button 
                        onClick={() => setResponseStatus('pending')}
                        className="text-xs text-white bg-bg-panel px-3 py-1.5 rounded border border-border-dark hover:border-primary mt-2"
                      >
                        Re-evaluate
                      </button>
                    </div>
                  ) : (
                    <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4 text-center">
                      <div className="text-amber-400 font-semibold mb-2">Actions Rolled Back</div>
                      <button 
                        onClick={() => setResponseStatus('pending')}
                        className="text-sm text-white bg-bg-dark px-4 py-2 rounded border border-border-dark hover:border-primary"
                      >
                        Re-evaluate
                      </button>
                    </div>
                  )}
                </div>
              </section>

              <section className="bg-bg-panel border border-border-dark rounded-xl p-5 shadow-lg flex flex-col">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-semibold text-white flex items-center gap-2 m-0">
                    <FileText className="w-5 h-5 text-primary" />
                    Incident Report & Audit
                  </h2>
                  <span className="text-xs font-mono text-text-muted">{incident.id}</span>
                </div>

                <div className="flex-1 bg-bg-dark rounded-lg border border-border-dark p-3 font-mono text-xs overflow-y-auto relative">
                  <div className="text-white font-bold text-center mb-3 border-b border-border-dark pb-2">AUDIT TRAIL LOG</div>
                  <div className="space-y-3">
                    {localAudit.map((log, i) => (
                      <div key={i} className="flex gap-2 text-gray-400 leading-tight">
                        <span className="text-gray-500 shrink-0">[{log.timestamp}]</span>
                        <span className={`shrink-0 w-16 font-bold ${log.actor === 'AI' ? 'text-primary' : log.actor === 'ANALYST' ? 'text-amber-400' : 'text-gray-500'}`}>
                          {log.actor}
                        </span>
                        <div>
                          <span className="text-gray-300 font-semibold">{log.event}</span><br/>
                          <span className="text-gray-500 text-[10px]">{log.details}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            </div>
          )}

        </div>
      </main>
      )}
    </div>
  );
}

