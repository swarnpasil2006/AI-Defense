import { describe, it, expect } from 'vitest';
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import App from '../src/App';
import { SecurityAnalyzer } from '../src/engine/Analyzer';
import { AttackSimulator } from '../src/simulation/AttackSimulator';
import type { SecurityEvent } from '../src/types/security';

describe('CyberSentinel AI Final Validation', () => {

  // 1. GOLDEN_DEMO is deterministic
  it('1. GOLDEN_DEMO is perfectly deterministic', () => {
    const run1 = AttackSimulator.generate('GOLDEN_DEMO');
    const run2 = AttackSimulator.generate('GOLDEN_DEMO');
    
    // Ignore IDs which use Math.random, check structural equality
    const stripDynamic = (events: SecurityEvent[]) => events.map(e => ({ action: e.action, user: e.user, ip: e.ip }));
    expect(stripDynamic(run1)).toEqual(stripDynamic(run2));
  });

  // 2. Failed logins + success → compromise evidence
  it('2. Failed logins + success yields Compromise evidence', () => {
    const events: SecurityEvent[] = [
      { id: '1', timestamp: '10:00', action: 'LOGIN_FAIL', user: 'admin', ip: '1.1.1.1' },
      { id: '2', timestamp: '10:01', action: 'LOGIN_FAIL', user: 'admin', ip: '1.1.1.1' },
      { id: '3', timestamp: '10:02', action: 'LOGIN_FAIL', user: 'admin', ip: '1.1.1.1' },
      { id: '4', timestamp: '10:05', action: 'LOGIN_SUCCESS', user: 'admin', ip: '1.1.1.1' }
    ];
    const incident = SecurityAnalyzer.analyze(events);
    expect(incident.evidence.some(e => e.text.includes('Successful login after failures'))).toBe(true);
  });

  // 3. Privilege escalation → additional risk
  it('3. Privilege escalation correctly adds risk', () => {
    const normalEvents: SecurityEvent[] = [
      { id: '1', timestamp: '10:00', action: 'LOGIN_SUCCESS', user: 'admin', ip: '1.1.1.1' }
    ];
    const normalIncident = SecurityAnalyzer.analyze(normalEvents);
    
    const escEvents: SecurityEvent[] = [
      ...normalEvents,
      { id: '2', timestamp: '10:01', action: 'PRIV_ESC', user: 'admin', ip: '1.1.1.1' }
    ];
    const escIncident = SecurityAnalyzer.analyze(escEvents);
    
    expect(escIncident.riskScore).toBeGreaterThan(normalIncident.riskScore);
  });

  // 4. Sensitive access → additional risk
  it('4. Sensitive file access correctly adds risk', () => {
    const normalEvents: SecurityEvent[] = [
      { id: '1', timestamp: '10:00', action: 'LOGIN_SUCCESS', user: 'admin', ip: '1.1.1.1' }
    ];
    const normalIncident = SecurityAnalyzer.analyze(normalEvents);
    
    const fileEvents: SecurityEvent[] = [
      ...normalEvents,
      { id: '2', timestamp: '10:01', action: 'FILE_ACCESS', user: 'admin', ip: '1.1.1.1', details: '/etc/shadow' }
    ];
    const fileIncident = SecurityAnalyzer.analyze(fileEvents);
    
    expect(fileIncident.riskScore).toBeGreaterThan(normalIncident.riskScore);
  });

  // 5. GOLDEN_DEMO → risk 85 / CRITICAL
  it('5. GOLDEN_DEMO yields >= 85 Risk and CRITICAL state', () => {
    const events = AttackSimulator.generate('GOLDEN_DEMO');
    const incident = SecurityAnalyzer.analyze(events);
    expect(incident.riskScore).toBeGreaterThanOrEqual(85);
    expect(incident.severity).toBe('CRITICAL');
  });

  // 6. Evidence provenance references real event IDs
  it('6. Evidence provenance perfectly maps to real source event IDs', () => {
    const events = AttackSimulator.generate('GOLDEN_DEMO');
    const incident = SecurityAnalyzer.analyze(events);
    
    const isValid = incident.evidence.every(e => 
      e.sourceEventIds.every(id => events.some(evt => evt.id === id))
    );
    expect(isValid).toBe(true);
  });

  // 7 & 8: Human-in-the-Loop tests require rendering the React App
  it('7. Human APPROVE executes the simulated containment action', () => {
    // Render the App (which defaults to GOLDEN_DEMO and is fully initialized)
    render(<App />);
    
    // Ensure it recommends containment
    expect(screen.getByText('Human Approval Required')).toBeInTheDocument();
    
    // Click APPROVE
    const approveBtn = screen.getByText('APPROVE');
    fireEvent.click(approveBtn);
    
    // Verify simulation executes
    const elements = screen.getAllByText('Simulation Executed');
    expect(elements.length).toBeGreaterThan(0);
    // It should also appear in the audit trail
    expect(screen.getByText(/Analyst authorized containment plan/i)).toBeInTheDocument();
  });

  it('8. Human REJECT strictly prevents simulated containment', () => {
    render(<App />);
    
    // Ensure it recommends containment
    expect(screen.getByText('Human Approval Required')).toBeInTheDocument();
    
    // Click REJECT
    const rejectBtn = screen.getByText('REJECT');
    fireEvent.click(rejectBtn);
    
    // Verify simulation is REJECTED
    expect(screen.getByText('Analyst Rejected Recommendation')).toBeInTheDocument();
    
    // MOST IMPORTANT: Prove Simulation did NOT execute
    expect(screen.queryByText('Simulation Executed')).not.toBeInTheDocument();
  });

  // 9. Malformed telemetry → graceful FAILURE
  it('9. Malformed telemetry triggers graceful FAILURE', () => {
    const incident = SecurityAnalyzer.analyze([]);
    expect(incident.severity).toBe('FAILURE');

    const malformed = SecurityAnalyzer.analyze([{ action: 'ERR' } as any]);
    expect(malformed.severity).toBe('FAILURE');
  });

  // 10. INSUFFICIENT_DEMO → does not falsely escalate to CRITICAL
  it('10. INSUFFICIENT_DEMO stays in INSUFFICIENT_EVIDENCE state', () => {
    const events = AttackSimulator.generate('INSUFFICIENT_DEMO');
    const incident = SecurityAnalyzer.analyze(events);
    
    expect(incident.severity).toBe('INSUFFICIENT_EVIDENCE');
    expect(incident.severity).not.toBe('CRITICAL');
  });

});
